package com.example.catalogomusica

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
