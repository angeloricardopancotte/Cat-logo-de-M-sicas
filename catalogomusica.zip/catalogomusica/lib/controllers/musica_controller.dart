import 'dart:convert';

import 'package:catalogomusica/models/musica.dart';
import 'package:http/http.dart' as http;

class MusicaController{
  final String baseUrl = "https://catalogo-de-musicas-default-rtdb.firebaseio.com/";
  final List<Musica> _musicas = [];

  Future<List<Musica>> getMusicas({bool? comprado}) async {
    final response = await http.get(Uri.parse('$baseUrl/musicas.json'));
    _musicas.clear();

    if (response.statusCode == 200) {
      if (response.body == "null") {
        return _musicas;
      }

      Map<String, dynamic> data = jsonDecode(response.body);
      bool filtraDados = false;
      if (comprado != null) filtraDados = true;

      data.forEach((musicaId, musicaData) {
        bool mostraDados = true;
        if (filtraDados) {
          if (musicaData['comprado']) {
            mostraDados = false;
          }
        }
        if (mostraDados) {
          _musicas.add(Musica(
            id: musicaId,
            titulo: musicaData['titulo'],
            artista: musicaData['artista'],
            album: musicaData['album'],
            genero: musicaData['genero'],
          ));
        }
      });
      return _musicas;
    } else {
      throw Exception('Erro ao obter os dados');
    }
  }

  Future<void> addMusica(Musica musica) async {
    final response = await http.post(
      Uri.parse('$baseUrl/musicas.json'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(musica.toJson()),  // Correção aqui
    );

    if (response.statusCode != 200) {
      throw Exception('Erro ao adicionar a musica');
    }
  }

  Future<void> updateMusica(Musica musica) async {
    final response = await http.post(
      Uri.parse('$baseUrl/musica/${musica.id}.json'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(musica.toJson()),  // Correção aqui
    );
    if (response.statusCode != 200) {
      throw Exception('Erro ao atualizar a musica');
    }
  }

  Future<void> deleteMusica(String id) async {
    final response = await http.delete(
      Uri.parse('$baseUrl/musica/$id.json'),
    );
    if (response.statusCode != 200) {
      throw Exception('Erro ao deletar a musica');
    }
  }
}