class Musica {
  final String? id;
  final String titulo;
  final String artista;
  final String album;
  final String genero;

  Musica({
    this.id,
    required this.titulo,
    required this.artista,
    required this.album,
    required this.genero,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'titulo': titulo,
      'artista': artista,
      'album': album,
      'genero': genero,
    };
  }
}